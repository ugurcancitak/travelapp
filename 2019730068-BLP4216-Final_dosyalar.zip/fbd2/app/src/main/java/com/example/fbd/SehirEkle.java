package com.example.fbd;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;

public class SehirEkle extends AppCompatActivity {
private TextView tw;
private EditText kaydetNot,kaydetSehir,ara;
private String notu,sehir,uid,aranacak;
private Button kayit;
private FirebaseAuth mAuth;
private FirebaseUser mUser;
private DatabaseReference mReference;
private HashMap<String, Object> mData;
private static final int ImageBack = 1;
private StorageReference Folder;
private String urldene;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sehir_ekle);
        Intent intent = getIntent();
        uid = intent.getStringExtra("uid");

        tw=findViewById(R.id.textView);
        tw.setText(uid.toString());

        kaydetNot=findViewById(R.id.kaydet_not);
        kaydetSehir=findViewById(R.id.kaydet_sehir);
        mAuth = FirebaseAuth.getInstance();
        //mUser=mAuth.getCurrentUser();
        mReference =  FirebaseDatabase.getInstance().getReference();
        Folder = FirebaseStorage.getInstance().getReference().child("ImageFolder");

        ara=findViewById(R.id.ara);





    }



    public void kaydet (View view) {
        notu = kaydetNot.getText().toString();
        sehir = kaydetSehir.getText().toString();
        if (!TextUtils.isEmpty(notu) && !TextUtils.isEmpty(sehir)){

        mUser = mAuth.getCurrentUser();


        mData=new HashMap<>();
        mData.put("sehir",sehir);
        mData.put("notu", notu);
        mData.put("imageurl",urldene);


        mReference.child("Kullanıcılar").child(uid).child("Ekledikleri").child(sehir)
                .setValue(mData)
                .addOnCompleteListener(SehirEkle.this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(SehirEkle.this,"Şehir ve not girildi.",Toast.LENGTH_SHORT).show();
                        }
                    }
                });




        }else{
            Toast.makeText(this,"değerler girilmeli",Toast.LENGTH_SHORT).show();

        }



    }
public void goruntuSec(View view){
Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
intent.setType("image/*");
startActivityForResult(intent,ImageBack);

}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==ImageBack){
            if(resultCode==RESULT_OK){
                Uri ImageData=data.getData();

                StorageReference Imagename = Folder.child("image" + ImageData.getLastPathSegment());
                Imagename.putFile(ImageData).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Toast.makeText(SehirEkle.this,"Yüklendi", Toast.LENGTH_SHORT).show();

                        Imagename.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                DatabaseReference imagestore=FirebaseDatabase.getInstance().getReference().child("Kullanıcılar").child(uid).child("Ekledikleri").child(sehir);
                                HashMap<String,String> hashMap = new HashMap<>();
                                hashMap.put("sehir",String.valueOf(sehir));
                                hashMap.put("not",String.valueOf(notu));
                                hashMap.put("imageurl",String.valueOf(uri));
                                imagestore.setValue(hashMap).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        urldene=String.valueOf(uri);
                                        Toast.makeText(SehirEkle.this,"Yüklendi.",Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        });
                    }
                });
            }

        }
    }

    public void eklediklerim(View view){
        Intent i = new Intent(SehirEkle.this,VeriAl.class);
        i.putExtra("uid",uid.toString());
        startActivity(i);


    }

    public void bul(View view){
        Intent yolla = new Intent(SehirEkle.this,VeriAra.class);
        aranacak=ara.getText().toString();
        yolla.putExtra("aranacakk",aranacak.toString());
        yolla.putExtra("uidx",uid.toString());
        startActivity(yolla);
    }



}
