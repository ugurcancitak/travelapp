package com.example.fbd;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Giris extends AppCompatActivity {

    private EditText editEmail, editSifre;
    private String txtEmail, txtSifre;
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private DatabaseReference mReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giris);
        editEmail=findViewById(R.id.giris_yap_editEmail);
        editSifre=findViewById(R.id.giris_yap_editSifre);
        mAuth=FirebaseAuth.getInstance();

    }

    public void GirisYap(View view){
        txtEmail = editEmail.getText().toString();
        txtSifre = editSifre.getText().toString();
        if (!TextUtils.isEmpty(txtEmail)&& !TextUtils.isEmpty(txtSifre)){
            mAuth.signInWithEmailAndPassword(txtEmail,txtSifre)
                    .addOnSuccessListener(this, new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            mUser=mAuth.getCurrentUser();

                            mReference= FirebaseDatabase.getInstance().getReference("Kullanıcılar").child(mUser.getUid());
                            mReference.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {

                                    for(DataSnapshot snp : snapshot.getChildren()){
                                        System.out.println(snp.getKey()+ "=" + snp.getValue());
                                    }
                                    Intent x = new Intent(Giris.this,SehirEkle.class);
                                    x.putExtra("uid",mUser.getUid());

                                    startActivity(x);

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
Toast.makeText(Giris.this,error.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });


                        }
                    }).addOnFailureListener(this, new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(Giris.this,e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

        }else{
            Toast.makeText(this,"Boş olmasın.", Toast.LENGTH_SHORT).show();
        }
    }

    public void gitkayit(View view){
        Intent i = new Intent(Giris.this,MainActivity.class);
        startActivity(i);
    }


}